Riproduci il layout fornito.
